document.addEventListener('DOMContentLoaded', function () {

  // 1) заменить картинку заднего фона на другую из папки image

  document.body.style.backgroundImage = "url('./image/you-dont-know-js.jpg')";

  // 2) удалить рекламу со страницы

  const adv = document.querySelector('.adv');
  if (adv) adv.remove();

  // 3) исправить заголовок в кинге 3

  const links = document.querySelectorAll('.book h2 a');
  links.forEach(function (a) {
    if (a.textContent.includes('Пропопипы')) {
      a.textContent = a.textContent.replace('Пропопипы', 'Прототипы');
    }
  });

});
